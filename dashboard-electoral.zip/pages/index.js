
// Simplificado para demo
export default function Home() {
  return (
    <div className="p-10">
      <h1 className="text-2xl font-bold">Dashboard Electoral</h1>
      <p>Versión rápida inicial 🚀</p>
    </div>
  )
}
